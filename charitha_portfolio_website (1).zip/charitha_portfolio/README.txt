CHARITHA BASAVARAJU — PORTFOLIO WEBSITE

Files:
- index.html: complete responsive portfolio website (HTML, CSS, and small amounts of browser-native behavior are in one file).

How to run:
1. Extract the ZIP file.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html.
4. Right-click in the editor and choose "Open with Live Server" if you have the Live Server extension.
   If you don't have Live Server, you can double-click index.html to open it in your browser.

Important:
- The portfolio uses only details Charitha has confirmed so far.
- GitHub profile link: https://github.com/charithabsj
- GreenBits is described as a project concept, not a completed/deployed project.
- No LeetCode profile or repository links are claimed.
- Update any content that no longer matches your actual work before publishing.

Publishing:
You can publish this folder using GitHub Pages. Create a new repository, upload index.html, then open:
Repository Settings > Pages > Deploy from a branch > select main and /(root) > Save.
Your GitHub Pages URL will be shown in the Pages section after deployment.
